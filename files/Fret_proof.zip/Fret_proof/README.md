FRET proof: Formal Requirements Elicitation Tool proof
======================================================

Running the Proof
-----------------

### Dependencies
* A Mac or Linux computer
* A working installation of PVS 7.1.0 (https://pvs.csl.sri.com/)
* A recent version of NASAlib, the standard library for PVS. (https://github.com/nasa/pvslib)
* Optional: The VSCode editor (https://code.visualstudio.com/), and PVS extension (https://github.com/nasa/vscode-pvs, or search extensions for PVS)
* Note: The simplest way to install these is to install VSCode, and then PVS extension. The extension will prompt to auto-install PVS and NASAlib. 

### Fret_proof folder
As you open the FRET_proof folder, you shall see the following directory structure:

```
.
├── Fretish_MTL
├── FretishAnimated
├── MTL_NuSMV
├── README.md
└── all-libraries
```

The folder FretishAnimated contains the definition of Fretish and its semantics; the folder MTL_NuSMV contains the semantics of the Metric Temporal Logic as defined for the NuSMV Model Checker; and the folder Fretish_MTL contains the formalization of the algorithm translating Fretish to MTL and the lemmas and theorems ensuring its correctness.
The main theorem is "fret_afteruntil_pmltl_equivalence" and it is located in the FretishToPastMLTL.pvs file in the Fretish_MTL folder.

### Adding the formalization to the PVS library path (optional for running in VSCode). 
To run the formalization from the terminal or emacs PVS interface, the path to NASAlib and the path to the Fret_proof folder must be in PVS library path. 

To do this dynamically, determine the locations of the NASAlib and Fret_proof folder (using "pwd" in the terminal, for example).
In the terminal, issue the command: 

`export PVS_LIBRARY_PATH="<path_to_nasalib>":"<path_to_Fret_proof>"`

This sets the path for the current terminal session. If the terminal is closed, this will need to be repeated. 


### Prove from the terminal
To run all proofs in the development from the terminal we use the PVS-included command `provethem`. After setting the library path as above, navigate to the "Fret_proof" folder and issue the command `provethem`. 

The output generated should indicate that each of the Fretish_MTL, FretishAnimated, and MTL_NuSMV folders have been successfully proved. 

More detailed output can be found in the output file all-theories.grandtotals, and to see the summary of each proof, there will be an output summary file for each folder. 

### Proving or examining from emacs interface
After setting the library path as above, navigate to one of the folders inside the Fret_proof folder. 

Start PVS, and open the "top.pvs" file. Enter the PVS command `prove-importchain` to prove all of the files in the current folder. Open any particular .pvs file in the folder to examine the formalization. (Note: Reading PVS files can be done in any text editor, as they are simply text.) Repeat the process in for each folder.

### Prove or examining from VSCode-PVS
To prove from VSCode-PVS, open the Fret_proof folder in a workspace. Click on the PVS icon on the icon bar on the left. The workspace explorer will display the Fret_proof directory of the selected folder. Hovering the cursor over the directory will show a blue play button. Click on the button and vscode will run the proofs in the directory. A summary of all the proofs will be displayed and also available in an output summary folder. 

In VSCode-PVS, it is also possible to run each proof individually or the proofs of a desired folder, and to see the proof tree as well. Instructions on how to do this in VSCode-PVS are detailed in https://github.com/nasa/vscode-pvs.

